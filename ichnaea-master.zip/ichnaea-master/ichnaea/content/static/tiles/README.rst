This directory contains datamaps images tiles produced by a
local development setup.
