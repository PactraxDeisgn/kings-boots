"""
Contains public website logic and assets.
"""
