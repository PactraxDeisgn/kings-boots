"""
Implementation of the public HTTP APIs related to transferring
aggregated station data from one service instance to another.
"""
