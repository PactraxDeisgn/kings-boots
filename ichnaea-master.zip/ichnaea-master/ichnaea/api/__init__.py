"""
Implementation of the public HTTP APIs.
"""
