"""
Implementation of the public HTTP APIs related to submitting new observed
or ground truth data to the service.
"""
