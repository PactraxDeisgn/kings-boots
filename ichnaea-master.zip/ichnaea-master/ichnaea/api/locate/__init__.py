"""
Implementation of the public HTTP APIs related to locating a user based
on provided data.
"""
