"""
Contains web app startup logic, configuration and runtime state.
"""
