"""
Contains celery beat and worker startup logic, configuration and runtime state.
"""
