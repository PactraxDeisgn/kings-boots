"""
Contains console script logic.
"""
