#!/bin/sh

exec /app/bin/location_map --create --upload
